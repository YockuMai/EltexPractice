#!/bin/bash
LOG="/root/practice3_eltex-pg1-v1_part2/cuckoo.log"
PIPE=""

for arg in "$@"; do
  case $arg in
    --prishitesuda=*|--pishitesuda=*) PIPE="${arg#*=}" ;;
  esac
done

if [ -z "$PIPE" ]; then
  echo "Не указан путь к каналу (--prishitesuda=...)" >&2
  exit 1
fi

PIPE_IN="$PIPE"
PIPE_OUT="${PIPE}.out"

rm -f "$PIPE_IN" "$PIPE_OUT"
mkfifo "$PIPE_IN" "$PIPE_OUT"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

log "Startup!"

cleanup() {
  log "Shutdown!"
  rm -f "$PIPE_IN" "$PIPE_OUT"
  exit 0
}
trap cleanup SIGTERM SIGINT

exec 3<>"$PIPE_IN"
exec 4<>"$PIPE_OUT"

re='^([^[]+)\[([0-9]+)\]: how much time do I have\?$'

while true; do
  if read -r line <&3; then
    if [[ "$line" =~ $re ]]; then
      name="${BASH_REMATCH[1]}"
      pid="${BASH_REMATCH[2]}"      

      N=$((RANDOM % 9 + 2))
      log "$name[$pid] $N${proc_name:+ (procfs: $proc_name)}"
      echo "$N" >&4
    fi
  fi
done
