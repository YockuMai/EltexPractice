#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

CONF="$SCRIPT_DIR/observer.conf"
LOG="$SCRIPT_DIR/observer.log"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

is_running() {
  local pattern="$1"
  local base
  base=$(basename "$pattern")
  local pid cmd
  for pid in /proc/[0-9]*; do
    [ -r "$pid/cmdline" ] || continue
    cmd=$(tr '\0' ' ' < "$pid/cmdline" 2>/dev/null)
    case "$cmd" in
      *"$pattern"*) return 0 ;;
    esac
    case "$cmd" in
      *"$base"*) return 0 ;;
    esac
  done
  return 1
}

if [ ! -r "$CONF" ]; then
  log "Файл конфигурации $CONF не найден"
  exit 1
fi

while IFS= read -r script || [ -n "$script" ]; do
  [ -z "$script" ] && continue
  case "$script" in \#*) continue ;; esac

  if is_running "$script"; then
    continue
  fi

  if [ ! -x "$script" ]; then
    log "Скрипт $script не найден или не исполняем"
    continue
  fi

  log "Скрипт $script не запущен, запускаю через nohup"
  nohup "$script" >/dev/null 2>&1 &
done < "$CONF"
