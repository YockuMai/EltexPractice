#!/bin/bash
BASENAME=$(basename "$0")

if [ "$BASENAME" = "template_task.sh" ]; then
  echo "я бригадир, сам не работаю"
  exit 0
fi

LOG="report_${BASENAME%.sh}.log"
PID=$$

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] $*" >> "$LOG"
}

log "Скрипт запущен"

CUCKOO_PID=$(pgrep -f 'cuckoo.sh.*prishitesuda' | head -n1)
if [ -z "$CUCKOO_PID" ]; then
  CUCKOO_PID=$(pgrep -f 'cuckoo.sh' | head -n1)
fi

if [ -z "$CUCKOO_PID" ]; then
  exit 1
fi

PIPE_IN=""
PIPE_OUT=""
for fd in /proc/"$CUCKOO_PID"/fd/*; do
  target=$(readlink "$fd" 2>/dev/null) || continue
  case "$target" in
    *cuckoo.pipe.out) PIPE_OUT="$target" ;;
    *cuckoo.pipe)     PIPE_IN="$target" ;;
  esac
done

if [ -z "$PIPE_IN" ] || [ -z "$PIPE_OUT" ]; then
  exit 1
fi

echo "$BASENAME[$PID]: how much time do I have?" > "$PIPE_IN"

if read -r N < "$PIPE_OUT"; then
  [[ "$N" =~ ^[0-9]+$ ]] || N=5
else
  N=5
fi

sleep "$N"

log "Скрипт завершился, работал $N секунд"
